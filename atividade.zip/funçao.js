function ExibirCadastro() {
  var textoHTML = '';
  for (let x = 0; x < Cadastro.length; x++) {
      let matricula=Cadastro[x].matricula;
      let curso=Cadastro[x].curso;
      let turma=Cadastro[x].turma;
      textoHTML += `Nome: ${Cadastro[x].nome} <br> Matricula:${matricula}<br> Curso:${curso} <br>turma:${turma}</li>`;

  };
  var tela = document.getElementById('tela');
  tela.innerHTML = textoHTML;